# IA_PARKINSON_LOGIC – NetSecurePro AI

Un projet intelligent pour la détection de Parkinson.